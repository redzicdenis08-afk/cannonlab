﻿$ErrorActionPreference = 'SilentlyContinue'
$destination = Join-Path $PSScriptRoot 'collected-logs'
New-Item -ItemType Directory -Force -Path $destination | Out-Null
$roots = @(
    (Join-Path $env:APPDATA '.minecraft'),
    (Join-Path $env:APPDATA 'Feather'),
    (Join-Path $env:USERPROFILE '.feather'),
    (Join-Path $env:APPDATA 'PrismLauncher\instances'),
    (Join-Path $env:APPDATA 'MultiMC\instances')
) | Where-Object { Test-Path $_ }
$folders = foreach ($root in $roots) {
    Get-ChildItem -Path $root -Directory -Recurse -Filter 'phaselab-verifier' -ErrorAction SilentlyContinue |
        Where-Object { $_.FullName -match '[\\/]config[\\/]phaselab-verifier$' }
}
$files = foreach ($folder in $folders) {
    Get-ChildItem $folder.FullName -File -Include 'session-*.jsonl','summary-*.json' -ErrorAction SilentlyContinue
}
$latest = $files | Sort-Object LastWriteTimeUtc -Descending | Select-Object -First 4
if (-not $latest) {
    Write-Host 'No PhaseLab logs found. Open the active instance folder and copy config\phaselab-verifier manually.'
    exit 1
}
foreach ($file in $latest) {
    $safeName = ($file.Directory.Parent.Parent.Name + '-' + $file.Name) -replace '[^A-Za-z0-9._-]','_'
    Copy-Item $file.FullName (Join-Path $destination $safeName) -Force
    Write-Host ('Copied ' + $file.FullName)
}
Write-Host ('Done: ' + $destination)
