﻿# PhaseLab 5.7 private-server test

This is the bounded target-authorized red-team build. It is not runtime-proven on your private plugin stack yet.

## Install

1. Remove every older `phaselab-client-*.jar` from the active Minecraft `mods` folder.
2. Add `phaselab-client-5.7.0-authenticated.jar`.
3. Fully restart Minecraft 1.21.11 Fabric.
4. On a non-loopback private target, add the exact multiplayer-list address to `.minecraft/config/phaselab-verifier/authorized-targets.txt` after the mod creates it.

## Controls

- `F7`: arm and run the selected bamboo-raft probe.
- `F6`: cycle profiles.
- `P`: legacy diagnostic ladder.
- `O`: abort.

Do not press `R`; 5.7 uses `F7`.

## First run

1. Use a normal bamboo raft on open flat ground first.
2. Mount it and immediately press `F7` once.
3. Keep hands off. The client waits ten ticks for the mount graph to stabilize before sending anything.
4. Default profile is `packet-only-005-3t`: 0.05-block absolute packets, one every three ticks, with synchronized input frames.
5. If it stays mounted, repeat against one obsidian plane with the raft center about 0.8 blocks before the wall.
6. If the far side is reached, open the far-side witness while still mounted, then dismount normally.
7. Use `F6` only after recording the result. Profiles increase through 0.10, 0.15, 0.20, 0.25, edge-leap, adaptive ramp, then legacy local-mirror.

## Evidence

After any detach or correction, preserve the newest files under:

`.minecraft/config/phaselab-verifier/`

The important result is the first terminal classification plus matching `PASSENGERS_*`, `PLAYER_CORRECTION_*`, `VEHICLE_CORRECTION_*`, `MOUNT_HANDSHAKE_STABLE`, and `PACKET_SEND` events. Client coordinates alone do not prove server acceptance.
